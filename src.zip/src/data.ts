export const leavesdata = [
  {
    id: 1,
    date: "1 May",
    description: " Planned Leave",
    type: "P",
  },
  {
    id: 2,
    date: "2 May",
    description: " Mandatory Leave",
    type: "M",
  },
  {
    id: 1,
    date: "3 May",
    description: " Sick Leave",
    type: "S",
  },

  {
    id: 4,
    date: "4 May",
    description: " Planned Leave",
    type: "P",
  },
  {
    id: 5,
    date: "5 May",
    description: " Mandatory Leave",
    type: "M",
  },
  {
    id: 6,
    date: "6 May",
    description: " Sick Leave",
    type: "S",
  },

  {
    id: 7,
    date: "7 May",
    description: " Planned Leave",
    type: "P",
  },
  {
    id: 8,
    date: "8 May",
    description: " Mandatory Leave",
    type: "M",
  },
  {
    id: 9,
    date: "9 May",
    description: " Sick Leave",
    type: "S",
  },

  {
    id: 10,
    date: "10 May",
    description: " Planned Leave",
    type: "P",
  },
  {
    id: 11,
    date: "11 May",
    description: " Mandatory Leave",
    type: "M",
  },
  {
    id: 12,
    date: "12 May",
    description: " Sick Leave",
    type: "S",
  },

  {
    id: 13,
    date: "13 May",
    description: " Planned Leave",
    type: "P",
  },
  {
    id: 14,
    date: "14 May",
    description: " Mandatory Leave",
    type: "M",
  },
  {
    id: 15,
    date: "15 May",
    description: " Sick Leave",
    type: "S",
  },
];
