import Dashboard from "./components/Dashboard/Dashboard"

const App = () =>{
  return <Dashboard/>
}
export default App