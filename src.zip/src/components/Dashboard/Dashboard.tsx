import LeaveList from "../LeaveList/LeaveList";
import styles from "./Dashboard.module.scss";
import { leavesdata } from "../../data";
import {
  ButtonHTMLAttributes,
  HTMLAttributes,
  JSXElementConstructor,
  ReactElement,
} from "react";
import { useState } from "react";

const Dashboard = () => {
  const [data, updateData] = useState(leavesdata);

  const updateLeave = (id: number, type: string) => {
    console.log(id, type);
    const updatedLeavesData = data.map((leave) => {
      if (leave.id === id) {
        return { ...leave, type: type };
      } else {
        return leave;
      }
    });
    console.log(updatedLeavesData);
    updateData(updatedLeavesData);
  };

  // const createButton = (text: "M" | "P" | "S") => {
  //   return (props )=>{
  //     return (
  //       <>
  //         <button {...props}>{text}</button>
  //       </>
  //     );
  //   };
  // };

  const createButton = (text: "M" | "P" | "S") => {
    return (props: EventListener): JSX.Element => {
      return (
        <>
          <button {...props}>{text}</button>;
        </>
      );
    };
  };
  const Mandatorybtn = createButton("M");
  const Plannedbtn = createButton("P");
  const Sickedbtn = createButton("S");

  return (
    <div className={styles.Dashboard}>
      <div className={styles.DashboardHeading}>
        <h1>Leaves Tracker</h1>
      </div>
      <div className={styles.LeavelistContainer}>
        <LeaveList
          title="Planned"
          leaves={data.filter((ele) => ele.type === "P")}
          updateLeave={updateLeave}
          action={[Mandatorybtn, Sickedbtn]}
        />
        <LeaveList
          title="Mandatory"
          leaves={data.filter((ele) => ele.type === "M")}
          updateLeave={updateLeave}
          action={[Plannedbtn, Sickedbtn]}
        />
        <LeaveList
          title="Sick"
          leaves={data.filter((ele) => ele.type === "S")}
          updateLeave={updateLeave}
          action={[Plannedbtn, Mandatorybtn]}
        />
      </div>
    </div>
  );
};
export default Dashboard;
