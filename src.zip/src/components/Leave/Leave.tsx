import { MouseEvent } from "react";
import styles from "./Leave.module.scss";
import { LeaveProps } from "./Leave.types";
const Leave = ({
  id,
  date,
  description,
  type,
  updateLeave,
  action,
}: LeaveProps) => {
  // const handleMove = (id: number, type: string) => {
  //   updateLeave(id, type);
  // };
  // const Mandatorybtn = <button onClick={() => handleMove(id, "M")}>M</button>;
  // const Plannedbtn = <button onClick={() => handleMove(id, "P")}>P</button>;
  // const Sickbtn = <button onClick={() => handleMove(id, "S")}>S</button>;

  // let ele;
  // if (type === "P") {
  //   ele = (
  //     <>
  //       {Mandatorybtn}
  //       {Sickbtn}
  //     </>
  //   );
  // } else if (type === "M") {
  //   ele = (
  //     <>
  //       {Plannedbtn}
  //       {Sickbtn}
  //     </>
  //   );
  // } else if (type === "S") {
  //   ele = (
  //     <>
  //       {Plannedbtn}
  //       {Mandatorybtn}
  //     </>
  //   );
  // }

  return (
    <div className={styles.Leave}>
      <div className={styles.LeaveInfo}>
        <span>{date}</span>
        <span>{description}</span>
      </div>
      <div className={styles.Btn}>
        {action.map((Btns) => (
          <Btns
            onClick={(e: MouseEvent) => updateLeave(id, e.target.innerText)}
          />
        ))}
      </div>
    </div>
  );
};
export default Leave;
