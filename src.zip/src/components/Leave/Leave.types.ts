import { ReactElement } from "react";

export interface LeaveProps {
  id: number;
  date: string;
  description: string;
  type: string;
  updateLeave: (id: number, type: string) => void;
  action: ((props: any) => JSX.Element)[];
}
